<section class="empty-state">
    <h2>چیزی پیدا نشد</h2>
    <p>لینک را بررسی کنید یا به صفحه دسته‌بندی‌ها برگردید.</p>
    <a class="primary-link" href="/categories">مشاهده دسته‌بندی‌ها</a>
</section>
