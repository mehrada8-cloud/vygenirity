<section class="card-grid" id="categories" data-endpoint="/api/categories">
    <div class="card loading">
        <h3>در حال بارگذاری...</h3>
        <p>دسته‌بندی‌های سیگنال در حال همگام‌سازی هستند.</p>
    </div>
</section>
